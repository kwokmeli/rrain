<?php get_header(); ?>
  <div class="row">

    <div class="col-sm-8 blog-main">


      </div><!-- /.blog-main -->
    </div><!-- /.row -->

<?php get_footer(); ?>
