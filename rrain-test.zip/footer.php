</div><!-- /.container -->

<footer class="blog-footer">
  <a href="ABOUT_URL">
  <img id="foot-img" src="<?php bloginfo('template_directory'); ?>/img/w.png" />
  <img id="foot-img" src="<?php bloginfo('template_directory'); ?>/img/doh.png" />
  <img id="foot-img" src="<?php bloginfo('template_directory'); ?>/img/nlm.png" /></a><br><br><br>

<div class="footer-text">
  RRAIN Washington is a joint project between the UW Health Sciences Library and the WA Department of Health
  with funding support from the NLM Contract No. HHS-N-276-2014-00658-P<br>
</div>
  <br><br><br><br>
  <div class="header-spacing"></div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
